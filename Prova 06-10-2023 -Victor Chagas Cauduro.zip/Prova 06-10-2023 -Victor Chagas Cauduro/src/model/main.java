package model;

import java.util.ArrayList;
import java.util.Scanner;

public class main {
    private ArrayList<Produto> produtoList = new ArrayList<>();
    private ArrayList<Categoria> categoriaList = new ArrayList<>();

    public static void main(String[] args) {
        main gp = new main();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Cadastrar categoria");
            System.out.println("2. Cadastrar produto");
            System.out.println("3. Dar entrada no produto no estoque");
            System.out.println("4. Dar saída do produto do estoque");
            System.out.println("5. Mostrar o saldo disponível de todos os produtos cadastrados");
            System.out.println("Escolha uma opção:");

            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o código da categoria:");
                    int codigoCategoria = scanner.nextInt();
                    System.out.println("Digite o nome da categoria:");
                    String nomeCategoria = scanner.next();
                    Categoria categoria = new Categoria(codigoCategoria, nomeCategoria);
                    gp.categoriaList.add(categoria);
                    break;
                case 2:
                    System.out.println("Digite o código do produto:");
                    int codigoProduto = scanner.nextInt();
                    System.out.println("Digite o nome do produto:");
                    String nomeProduto = scanner.next();
                    System.out.println("Digite o preço do produto:");
                    double precoProduto = scanner.nextDouble();
                    System.out.println("Digite a quantidade do produto:");
                    int quantidadeProduto = scanner.nextInt();
                    System.out.println("Digite o código da categoria do produto:");
                    int codigoCategoriaProduto = scanner.nextInt();
                    for(Categoria cat : gp.categoriaList) {
                        if(cat.getCodigoCategoria() == codigoCategoriaProduto) {
                            Produto produto = new Produto(codigoProduto, nomeProduto, precoProduto, quantidadeProduto, cat);
                            gp.produtoList.add(produto);
                            break;
                        }
                    }
                    break;
                case 3:
                    System.out.println("Digite o código do produto:");
                    int codigoEntrada = scanner.nextInt();
                    for(Produto prod : gp.produtoList) {
                        if(prod.getCodigo() == codigoEntrada) {
                            System.out.println("Digite a quantidade a ser adicionada:");
                            int quantidadeEntrada = scanner.nextInt();
                            prod.entradaEstoque(quantidadeEntrada);
                            break;
                        }
                    }
                    break;
                case 4:
                    System.out.println("Digite o código do produto:");
                    int codigoSaida = scanner.nextInt();
                    for(Produto prod : gp.produtoList) {
                        if(prod.getCodigo() == codigoSaida) {
                            System.out.println("Digite a quantidade a ser removida:");
                            int quantidadeSaida = scanner.nextInt();
                            prod.saidaEstoque(quantidadeSaida);
                            break;
                        }
                    }
                    break;
                case 5:
                    for(Produto prod : gp.produtoList) {
                        System.out.println("Código: " + prod.getCodigo());
                        System.out.println("Nome: " + prod.getNome());
                        System.out.println("Saldo: " + prod.getSaldo());
                        System.out.println("-------------------------");
                    }
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }
}
